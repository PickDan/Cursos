package com.spring.cursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursosSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
